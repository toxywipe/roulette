<?php

function controleurPrincipal($action) {
    // Tableau associatif qui relie chaque action à son fichier contrôleur
    $lesActions = array();
    $lesActions["defaut"] = "vueListeEtudiant.php";
    $lesActions["showStudents"] = "vueListeEtudiant.php";
    $lesActions["drawStudent"] = "vueListeEtudiant.php";
    $lesActions["setGrade"] = "vueListeEtudiant.php";
    $lesActions["showClasses"] = "vueListeEtudiant.php";
    $lesActions["addClass"] = "vueListeEtudiant.php";

    // Vérifie si l'action existe dans le tableau et retourne le fichier associé
    if (array_key_exists($action, $lesActions)) {
        return $lesActions[$action];
    } else {
        return $lesActions["defaut"];
    }
}

?>
